#include "./BSP/HALLSENSOR/hallsensor.h"
#include "./SYSTEM/delay/delay.h"

void hallsensor_init(void)
{
    GPIO_InitTypeDef gpio_init_struct;
    

//    __HAL_AFIO_REMAP_SWJ_NOJTAG();
//    __HAL_AFIO_REMAP_SWJ_NONJTRST();
    
    HALL_SENSOR_Y_GPIO_CLK_ENABLE();
    
    gpio_init_struct.Pin = HALL_SENSOR_Y_GPIO_PIN;                       /* WKUP���� */
    gpio_init_struct.Mode = GPIO_MODE_INPUT;                    /* ���� */
    gpio_init_struct.Pull = GPIO_PULLUP;                      /* ���� */
    gpio_init_struct.Speed = GPIO_SPEED_FREQ_HIGH;              /* ���� */
    HAL_GPIO_Init(HALL_SENSOR_Y_GPIO_PORT, &gpio_init_struct);           /* WKUP����ģʽ����,�������� */
    
    
    HALL_SENSOR_G_GPIO_CLK_ENABLE();
    
    gpio_init_struct.Pin = HALL_SENSOR_G_GPIO_PIN;                       /* WKUP���� */
    gpio_init_struct.Mode = GPIO_MODE_INPUT;                    /* ���� */
    gpio_init_struct.Pull = GPIO_PULLUP;                      /* ���� */
    gpio_init_struct.Speed = GPIO_SPEED_FREQ_HIGH;              /* ���� */
    HAL_GPIO_Init(HALL_SENSOR_G_GPIO_PORT, &gpio_init_struct);           /* WKUP����ģʽ����,�������� */
    
    HALL_SENSOR_B_GPIO_CLK_ENABLE();
    
    gpio_init_struct.Pin = HALL_SENSOR_B_GPIO_PIN;                       /* WKUP���� */
    gpio_init_struct.Mode = GPIO_MODE_INPUT;                    /* ���� */
    gpio_init_struct.Pull = GPIO_PULLUP;                      /* ���� */
    gpio_init_struct.Speed = GPIO_SPEED_FREQ_HIGH;              /* ���� */
    HAL_GPIO_Init(HALL_SENSOR_B_GPIO_PORT, &gpio_init_struct);           /* WKUP����ģʽ����,�������� */
    
    HALL_SENSOR2_Y_GPIO_CLK_ENABLE();
    
    gpio_init_struct.Pin = HALL_SENSOR2_Y_GPIO_PIN;                       /* WKUP���� */
    gpio_init_struct.Mode = GPIO_MODE_INPUT;                    /* ���� */
    gpio_init_struct.Pull = GPIO_PULLUP;                      /* ���� */
    gpio_init_struct.Speed = GPIO_SPEED_FREQ_HIGH;              /* ���� */
    HAL_GPIO_Init(HALL_SENSOR2_Y_GPIO_PORT, &gpio_init_struct);           /* WKUP����ģʽ����,�������� */
    
    
    HALL_SENSOR2_G_GPIO_CLK_ENABLE();
    
    gpio_init_struct.Pin = HALL_SENSOR2_G_GPIO_PIN;                       /* WKUP���� */
    gpio_init_struct.Mode = GPIO_MODE_INPUT;                    /* ���� */
    gpio_init_struct.Pull = GPIO_PULLUP;                      /* ���� */
    gpio_init_struct.Speed = GPIO_SPEED_FREQ_HIGH;              /* ���� */
    HAL_GPIO_Init(HALL_SENSOR2_G_GPIO_PORT, &gpio_init_struct);           /* WKUP����ģʽ����,�������� */
    
    HALL_SENSOR2_B_GPIO_CLK_ENABLE();
    
    gpio_init_struct.Pin = HALL_SENSOR2_B_GPIO_PIN;                       /* WKUP���� */
    gpio_init_struct.Mode = GPIO_MODE_INPUT;                    /* ���� */
    gpio_init_struct.Pull = GPIO_PULLUP;                      /* ���� */
    gpio_init_struct.Speed = GPIO_SPEED_FREQ_HIGH;              /* ���� */
    HAL_GPIO_Init(HALL_SENSOR2_B_GPIO_PORT, &gpio_init_struct);           /* WKUP����ģʽ����,�������� */
}

uint8_t hallsensor_Scan(void){

    if(!HALL_SENSOR_Y && !HALL_SENSOR_B && HALL_SENSOR_G){
        return 1;
    }else if(!HALL_SENSOR_Y &&  HALL_SENSOR_B &&  HALL_SENSOR_G){
        return 2;
    }else if(!HALL_SENSOR_Y &&  HALL_SENSOR_B && !HALL_SENSOR_G){
        return 3;
    }else if( HALL_SENSOR_Y &&  HALL_SENSOR_B && !HALL_SENSOR_G){
        return 4;
    }else if( HALL_SENSOR_Y && !HALL_SENSOR_B && !HALL_SENSOR_G){
        return 5;
    }else if( HALL_SENSOR_Y && !HALL_SENSOR_B &&  HALL_SENSOR_G){
        return 6;
    }else{
        return 9;
    }
}

uint8_t hallsensor2_Scan(void){
    
    if(!HALL_SENSOR2_Y && !HALL_SENSOR2_B && HALL_SENSOR2_G){
        return 1;
    }else if(!HALL_SENSOR2_Y &&  HALL_SENSOR2_B &&  HALL_SENSOR2_G){
        return 2;
    }else if(!HALL_SENSOR2_Y &&  HALL_SENSOR2_B && !HALL_SENSOR2_G){
        return 3;
    }else if( HALL_SENSOR2_Y &&  HALL_SENSOR2_B && !HALL_SENSOR2_G){
        return 4;
    }else if( HALL_SENSOR2_Y && !HALL_SENSOR2_B && !HALL_SENSOR2_G){
        return 5;
    }else if( HALL_SENSOR2_Y && !HALL_SENSOR2_B &&  HALL_SENSOR2_G){
        return 6;
    }else{
        return 9;
    }
}



















