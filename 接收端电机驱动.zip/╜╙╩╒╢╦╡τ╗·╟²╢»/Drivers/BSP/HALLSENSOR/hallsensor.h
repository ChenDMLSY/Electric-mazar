
#ifndef __HALLSENSOR_H
#define __HALLSENSOR_H

#include "./SYSTEM/sys/sys.h"

/******************************************************************************************/
/* ���� ���� */

/******************************************************************************************/
#define HALL_SENSOR_Y_GPIO_PORT                     GPIOB
#define HALL_SENSOR_Y_GPIO_PIN                      GPIO_PIN_9
#define HALL_SENSOR_Y_GPIO_CLK_ENABLE()             do{__HAL_RCC_GPIOB_CLK_ENABLE();}while(0)

#define HALL_SENSOR_B_GPIO_PORT                     GPIOB
#define HALL_SENSOR_B_GPIO_PIN                      GPIO_PIN_10
#define HALL_SENSOR_B_GPIO_CLK_ENABLE()             do{__HAL_RCC_GPIOB_CLK_ENABLE();}while(0)

#define HALL_SENSOR_G_GPIO_PORT                     GPIOB
#define HALL_SENSOR_G_GPIO_PIN                      GPIO_PIN_11
#define HALL_SENSOR_G_GPIO_CLK_ENABLE()             do{__HAL_RCC_GPIOB_CLK_ENABLE();}while(0)

#define HALL_SENSOR2_Y_GPIO_PORT                     GPIOB
#define HALL_SENSOR2_Y_GPIO_PIN                      GPIO_PIN_6
#define HALL_SENSOR2_Y_GPIO_CLK_ENABLE()             do{__HAL_RCC_GPIOB_CLK_ENABLE();}while(0)

#define HALL_SENSOR2_B_GPIO_PORT                     GPIOB
#define HALL_SENSOR2_B_GPIO_PIN                      GPIO_PIN_7
#define HALL_SENSOR2_B_GPIO_CLK_ENABLE()             do{__HAL_RCC_GPIOB_CLK_ENABLE();}while(0)

#define HALL_SENSOR2_G_GPIO_PORT                     GPIOB
#define HALL_SENSOR2_G_GPIO_PIN                      GPIO_PIN_8
#define HALL_SENSOR2_G_GPIO_CLK_ENABLE()             do{__HAL_RCC_GPIOB_CLK_ENABLE();}while(0)


/******************************************************************************************/

#define HALL_SENSOR_Y         HAL_GPIO_ReadPin(HALL_SENSOR_Y_GPIO_PORT,  HALL_SENSOR_Y_GPIO_PIN)
#define HALL_SENSOR_B         HAL_GPIO_ReadPin(HALL_SENSOR_B_GPIO_PORT,  HALL_SENSOR_B_GPIO_PIN)
#define HALL_SENSOR_G         HAL_GPIO_ReadPin(HALL_SENSOR_G_GPIO_PORT,  HALL_SENSOR_G_GPIO_PIN)

#define HALL_SENSOR2_Y        HAL_GPIO_ReadPin(HALL_SENSOR2_Y_GPIO_PORT, HALL_SENSOR2_Y_GPIO_PIN)
#define HALL_SENSOR2_B        HAL_GPIO_ReadPin(HALL_SENSOR2_B_GPIO_PORT, HALL_SENSOR2_B_GPIO_PIN)
#define HALL_SENSOR2_G        HAL_GPIO_ReadPin(HALL_SENSOR2_G_GPIO_PORT, HALL_SENSOR2_G_GPIO_PIN)

void hallsensor_init(void);                /* ������ʼ������ */
uint8_t hallsensor_Scan(void);
uint8_t hallsensor2_Scan(void);

#endif


















