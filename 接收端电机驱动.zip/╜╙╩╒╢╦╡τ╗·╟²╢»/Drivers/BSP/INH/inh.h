#ifndef __INH_H
#define __INH_H
#include "./SYSTEM/sys/sys.h"


#define INH_U_GPIO_PORT                  GPIOB
#define INH_U_GPIO_PIN                   GPIO_PIN_3
#define INH_U_GPIO_CLK_ENABLE()          do{ __HAL_RCC_GPIOB_CLK_ENABLE(); }while(0)             /* PE��ʱ��ʹ�� */

#define INH_V_GPIO_PORT                  GPIOB
#define INH_V_GPIO_PIN                   GPIO_PIN_4
#define INH_V_GPIO_CLK_ENABLE()         do{ __HAL_RCC_GPIOB_CLK_ENABLE(); }while(0)             /* PE��ʱ��ʹ�� */

#define INH_W_GPIO_PORT                  GPIOB
#define INH_W_GPIO_PIN                   GPIO_PIN_5
#define INH_W_GPIO_CLK_ENABLE()         do{ __HAL_RCC_GPIOB_CLK_ENABLE(); }while(0)             /* PE��ʱ��ʹ�� */

#define INH2_U_GPIO_PORT                  GPIOA
#define INH2_U_GPIO_PIN                   GPIO_PIN_11
#define INH2_U_GPIO_CLK_ENABLE()          do{ __HAL_RCC_GPIOA_CLK_ENABLE(); }while(0)             /* PE��ʱ��ʹ�� */

#define INH2_V_GPIO_PORT                  GPIOA
#define INH2_V_GPIO_PIN                   GPIO_PIN_12
#define INH2_V_GPIO_CLK_ENABLE()         do{ __HAL_RCC_GPIOA_CLK_ENABLE(); }while(0)             /* PE��ʱ��ʹ�� */

#define INH2_W_GPIO_PORT                  GPIOA
#define INH2_W_GPIO_PIN                   GPIO_PIN_15
#define INH2_W_GPIO_CLK_ENABLE()         do{ __HAL_RCC_GPIOA_CLK_ENABLE(); }while(0)             /* PE��ʱ��ʹ�� */


#define INH_U(x)   do{ x ? \
                    HAL_GPIO_WritePin(INH_U_GPIO_PORT, INH_U_GPIO_PIN, GPIO_PIN_SET) : \
                    HAL_GPIO_WritePin(INH_U_GPIO_PORT, INH_U_GPIO_PIN, GPIO_PIN_RESET); \
                  }while(0)      /* LED1��ת */

#define INH_V(x)   do{ x ? \
                    HAL_GPIO_WritePin(INH_V_GPIO_PORT, INH_V_GPIO_PIN, GPIO_PIN_SET) : \
                    HAL_GPIO_WritePin(INH_V_GPIO_PORT, INH_V_GPIO_PIN, GPIO_PIN_RESET); \
                  }while(0)      /* LED1��ת */

#define INH_W(x)   do{ x ? \
                    HAL_GPIO_WritePin(INH_W_GPIO_PORT, INH_W_GPIO_PIN, GPIO_PIN_SET) : \
                    HAL_GPIO_WritePin(INH_W_GPIO_PORT, INH_W_GPIO_PIN, GPIO_PIN_RESET); \
                  }while(0)      /* LED1��ת */

#define INH2_U(x)   do{ x ? \
                    HAL_GPIO_WritePin(INH2_U_GPIO_PORT, INH2_U_GPIO_PIN, GPIO_PIN_SET) : \
                    HAL_GPIO_WritePin(INH2_U_GPIO_PORT, INH2_U_GPIO_PIN, GPIO_PIN_RESET); \
                  }while(0)      /* LED1��ת */

#define INH2_V(x)   do{ x ? \
                    HAL_GPIO_WritePin(INH2_V_GPIO_PORT, INH2_V_GPIO_PIN, GPIO_PIN_SET) : \
                    HAL_GPIO_WritePin(INH2_V_GPIO_PORT, INH2_V_GPIO_PIN, GPIO_PIN_RESET); \
                  }while(0)      /* LED1��ת */

#define INH2_W(x)   do{ x ? \
                    HAL_GPIO_WritePin(INH2_W_GPIO_PORT, INH2_W_GPIO_PIN, GPIO_PIN_SET) : \
                    HAL_GPIO_WritePin(INH2_W_GPIO_PORT, INH2_W_GPIO_PIN, GPIO_PIN_RESET); \
                  }while(0)      /* LED1��ת */
void inh_init(void);
                  
#endif



