
/*==================================================================

*AS5600��IIC��PB10    PB11    T1��ʱ

*�ɿ�����pwm��PB7(T4C2)

*���pwm����BTS7960��B0(T3C3)   B1(T3C4)    ��B0,B1��ͨ����PWM��0����0��PWM����������ת

*��ʾ�������PB5

*ʹ��EN�����PA1
*==================================================================*/
#include "./SYSTEM/sys/sys.h"
#include "./SYSTEM/usart/usart.h"
#include "./SYSTEM/delay/delay.h"
#include "./BSP/TIMER/gtim.h"
#include "./BSP/ADC/adc.h"
#include "./BSP/NRF24L01/nrf24L01.h"
#include "./BSP/HALLSENSOR/hallsensor.h"
#include "./BSP/INH/inh.h"

#define ADC_DMA_BUF_SIZE        50 * 2      /* ADC DMA�ɼ� BUF��С, Ӧ����ADCͨ������������ */



extern uint16_t g_adc_dma_buf[ADC_DMA_BUF_SIZE];   /* ADC DMA BUF */

extern uint8_t g_adc_dma_sta;               /* DMA����״̬��־, 0,δ���; 1, ����� */

extern TIM_HandleTypeDef g_tim3_pwm_ch_handle;     /* ��ʱ��3ch3���     PB0     */
extern TIM_HandleTypeDef g_tim2_pwm_ch_handle;     /* ��ʱ��3ch3���     PB0     */
extern TIM_HandleTypeDef b_tim4_cnt_ch1_handle; /* ��ʱ��x��� */
extern TIM_HandleTypeDef b_tim4_cnt_ch2_handle; /* ��ʱ��x��� */
uint16_t max_duty=700;
uint16_t max_speed;

uint8_t motor_dir1,motor_dir2;
uint16_t DutyCycle1=0,DutyCycle2=0;

uint32_t IS[3];
uint16_t delta1,delta2;
int16_t delta;

//extern uint8_t hall_state1,hall_state2;
extern uint8_t gtim_motor_dir1,gtim_motor_dir2;

extern uint16_t aim_velocity1,aim_velocity2;

uint16_t map(uint16_t val,uint16_t I_min,uint16_t I_max,uint16_t O_min,uint16_t O_max)
{
  if(val<I_min)
    {
      return O_min;
    }
  if(val>I_max)
    {
      return O_max;
    }
  return (((val-I_min)*(O_max-O_min))/(I_max-I_min))+O_min;
}


void Motor_run(uint8_t M_dir,uint16_t M_DutyCycle){
    if(M_dir){
        switch(hallsensor_Scan()){
            case 6:
                INH_U(0);
                INH_V(1);
                INH_W(1);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH2, 0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH3, 0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH4, M_DutyCycle);
                break;
            case 1:
                INH_U(1);
                INH_V(1);
                INH_W(0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH2, M_DutyCycle);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH3, 0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH4, 0);
                break;
            case 2:
                INH_U(1);
                INH_V(0);
                INH_W(1);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH2, M_DutyCycle);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH3, 0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH4, 0);
                break;
            case 3:
                INH_U(0);
                INH_V(1);
                INH_W(1);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH2, 0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH3, M_DutyCycle);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH4, 0);
                break;
            case 4:
                INH_U(1);
                INH_V(1);
                INH_W(0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH2, 0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH3, M_DutyCycle);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH4, 0);
                break;
            case 5:
                INH_U(1);
                INH_V(0);
                INH_W(1);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH2, 0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH3, 0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH4, M_DutyCycle);
                break;
            default:
                INH_U(0);
                INH_V(0);
                INH_W(0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH2, 0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH3, 0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH4, 0);
                break;
        }
    }else{
        switch(hallsensor_Scan()){
            case 6:
                INH_U(0);
                INH_V(1);
                INH_W(1);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH2, 0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH3, M_DutyCycle);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH4, 0);
                break;
            case 1:
                INH_U(1);
                INH_V(1);
                INH_W(0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH2, 0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH3, M_DutyCycle);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH4, 0);
                break;
            case 2:
                INH_U(1);
                INH_V(0);
                INH_W(1);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH2, 0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH3, 0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH4, M_DutyCycle);
                break;
            case 3:
                INH_U(0);
                INH_V(1);
                INH_W(1);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH2, 0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH3, 0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH4, M_DutyCycle);
                break;
            case 4:
                INH_U(1);
                INH_V(1);
                INH_W(0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH2, M_DutyCycle);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH3, 0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH4, 0);
                break;
            case 5:
                INH_U(1);
                INH_V(0);
                INH_W(1);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH2, M_DutyCycle);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH3, 0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH4, 0);
                break;
            default:
                INH_U(0);
                INH_V(0);
                INH_W(0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH2, 0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH3, 0);
                __HAL_TIM_SET_COMPARE(&g_tim2_pwm_ch_handle, GTIM_TIM2_PWM_CH4, 0);
                break;
        }
    }
}
void Motor2_run(uint8_t M_dir,uint16_t M_DutyCycle)
{
  if(M_dir)
    {
      switch(hallsensor2_Scan())
        {
        case 6:
          INH2_U(0);
          INH2_V(1);
          INH2_W(1);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH1, 0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH3, 0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH4, M_DutyCycle);
          break;
        case 1:
          INH2_U(1);
          INH2_V(1);
          INH2_W(0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH1, M_DutyCycle);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH3, 0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH4, 0);
          break;
        case 2:
          INH2_U(1);
          INH2_V(0);
          INH2_W(1);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH1, M_DutyCycle);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH3, 0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH4, 0);
          break;
        case 3:
          INH2_U(0);
          INH2_V(1);
          INH2_W(1);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH1, 0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH3, M_DutyCycle);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH4, 0);
          break;
        case 4:
          INH2_U(1);
          INH2_V(1);
          INH2_W(0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH1, 0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH3, M_DutyCycle);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH4, 0);
          break;
        case 5:
          INH2_U(1);
          INH2_V(0);
          INH2_W(1);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH1, 0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH3, 0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH4, M_DutyCycle);
          break;
        default:
          INH2_U(0);
          INH2_V(0);
          INH2_W(0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH1, 0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH3, 0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH4, 0);
          break;
        }
    }else{
      switch(hallsensor2_Scan())
        {
        case 6:
          INH2_U(0);
          INH2_V(1);
          INH2_W(1);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH1, 0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH3, M_DutyCycle);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH4, 0);
          break;
        case 1:
          INH2_U(1);
          INH2_V(1);
          INH2_W(0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH1, 0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH3, M_DutyCycle);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH4, 0);
          break;
        case 2:
          INH2_U(1);
          INH2_V(0);
          INH2_W(1);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH1, 0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH3, 0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH4, M_DutyCycle);
          break;
        case 3:
          INH2_U(0);
          INH2_V(1);
          INH2_W(1);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH1, 0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH3, 0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH4, M_DutyCycle);
          break;
        case 4:
          INH2_U(1);
          INH2_V(1);
          INH2_W(0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH1, M_DutyCycle);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH3, 0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH4, 0);
          break;
        case 5:
          INH2_U(1);
          INH2_V(0);
          INH2_W(1);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH1, M_DutyCycle);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH3, 0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH4, 0);
          break;
        default:
          INH2_U(0);
          INH2_V(0);
          INH2_W(0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH1, 0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH3, 0);
          __HAL_TIM_SET_COMPARE(&g_tim3_pwm_ch_handle, GTIM_TIM3_PWM_CH4, 0);
          break;
        }
    }
}
void Get_DirDuty(void)
{
  if((IS[0]<=2195)&&(IS[1]<=2195)&&(IS[0]>700)&&(IS[1]>700))
    {
      if(IS[0]<=2000)
        {
          delta1=2000-IS[0];
        }
      else
        {
          delta1=0;
        }
      if(IS[1]<=2000)
        {
          delta2=2000-IS[1];
        }
      else
        {
          delta2=0;
        }
      delta=delta2-delta1;
      if(delta>=0)
        {
          motor_dir1=1;
          DutyCycle2=(map(delta,0,1100,0,max_speed))/2;
        }
      else
        {
          motor_dir1=0;
          DutyCycle2=map(0-delta,0,1100,0,max_speed);
        }
      motor_dir2=1;
      DutyCycle1=map((delta1+delta2),0,1100,0,max_speed);
        

    }
  if((IS[0]>=2000)&&(IS[1]<=2195)&&(IS[0]<3500)&&(IS[1]>700))
    {
      if(IS[0]>=2200)
        {
          delta1=IS[0]-2200;
        }
      else
        {
          delta1=0;
        }
      if(IS[1]<=2000)
        {
          delta2=2000-IS[1];
        }
      else
        {
          delta2=0;
        }
      delta=delta2-delta1;
      if(delta>=0)
        {
          motor_dir2=1;
          DutyCycle2=(map(delta,0,1100,0,max_speed))/2;
        }
      else
        {
          motor_dir2=0;
          DutyCycle2=map(0-delta,0,1100,0,max_speed);
        }
      motor_dir1=1;
      DutyCycle1=map((delta1+delta2),0,1100,0,max_speed);
    }
  if((IS[0]>=2000)&&(IS[1]>=2000)&&(IS[0]<3500)&&(IS[1]<3500))
    {
      if(IS[0]>=2200)
        {
          delta1=IS[0]-2200;
        }
      else
        {
          delta1=0;
        }
      if(IS[1]>=2200)
        {
          delta2=IS[1]-2200;
        }
      else
        {
          delta2=0;
        }
      delta=delta2-delta1;
      if(delta>=0)
        {
          motor_dir1=0;
          DutyCycle1=(map(delta,0,1100,0,max_speed))/2;
        }
      else
        {
          motor_dir1=1;
          DutyCycle1=map(0-delta,0,1100,0,max_speed);
        }
      motor_dir2=0;
      DutyCycle2=map((delta1+delta2),0,1100,0,max_speed);
        
    }
  if((IS[0]<=2195)&&(IS[1]>=2000)&&(IS[0]>700)&&(IS[1]<3500))
    {
      if(IS[0]<=2000)
        {
          delta1=2000-IS[0];
        }
      else
        {
          delta1=0;
        }
      if(IS[1]>=2200)
        {
          delta2=IS[1]-2200;
        }
      else
        {
          delta2=0;
        }
      delta=delta2-delta1;
      if(delta>=0)
        {
          motor_dir2=0;
          DutyCycle1=(map(delta,0,1100,0,max_speed))/2;
        }
      else
        {
          motor_dir2=1;
          DutyCycle1=map(0-delta,0,1100,0,max_speed);
        }
      motor_dir1=0;
      DutyCycle2=map((delta1+delta2),0,1100,0,max_speed);
    }
  if((IS[0]<700)||(IS[1]<700)||(IS[0]>3500)||(IS[1]>3500))
    {
      DutyCycle1=0;
      DutyCycle2=0;
    }

  gtim_motor_dir1=motor_dir1;
  gtim_motor_dir2=motor_dir2;
  aim_velocity1=DutyCycle1;
  aim_velocity2=DutyCycle2;
  
//    printf("    motor_dir1:%u\t",gtim_motor_dir1);
}
int main(void)
{
  uint8_t main_tmp_buf[32],main_t;
  uint16_t main_adc[3];


  HAL_Init();                             /* ��ʼ��HAL�� */
  sys_stm32_clock_init(RCC_PLL_MUL9);     /* ����ʱ��, 72Mhz */
  delay_init(72);                         /* ��ʱ��ʼ�� */
  usart_init(115200);                     /* ���ڳ�ʼ��Ϊ115200 */
  hallsensor_init();                /* ������ʼ������ */
  inh_init();

  gtim_tim3_pwm_ch_init(1000 - 1, 36 - 1);/* 1Mhz�ļ���Ƶ��,2Khz��PWM. */

  gtim_tim2_pwm_ch_init(1000 - 1, 36 - 1);/* 1Mhz�ļ���Ƶ��,2Khz��PWM. */

  btim_tim4_cnt_ch1_init(3599); /* 10Khz�ļ���Ƶ�ʣ�����500��Ϊ100ms *///     5/6
  btim_tim4_cnt_ch2_init(3599); /* 10Khz�ļ���Ƶ�ʣ�����500��Ϊ100ms *///     5/6
    
  atim_timx_int_init(20 - 1, 3600 - 1);
  
  adc_nch_dma_init((uint32_t)&g_adc_dma_buf); /* ��ʼ��ADC DMA�ɼ� */
  adc_dma_enable(ADC_DMA_BUF_SIZE);   /* ����ADC DMA�ɼ� */

  NRF24L01_SPI_Init();    		//��ʼ��NRF24L01

  while(NRF24L01_Check())
    {
      printf("Ӳ����Ѱ����NRF24L01����ģ��\n");

      HAL_Delay(1000);
    }
  printf("NRF24L01����ģ��Ӳ����������\n");

  NRF24L01_RX_Mode();

  printf("�������ݽ���ģʽ\n");

  Kaleman_Parameter_Init();
  while (1)
    {
      while(1)
        {
          Motor2_run(motor_dir2,DutyCycle2);
          Motor_run(motor_dir1,DutyCycle1);

          if(NRF24L01_RxPacket(main_tmp_buf)==0)
            {
              for(main_t=0; main_t<3; main_t++)
                {
                  IS[main_t] = (uint16_t) (main_tmp_buf[2*main_t] << 8) | main_tmp_buf[2*main_t+1];
                }
            }
          max_speed=map(IS[2],0,4096,300,700);
          Get_DirDuty();
//            printf("IS[0]:%u  ",IS[0]);
//            printf("IS[1]:%u  ",IS[1]);
//            printf("SED:%u  ",max_speed);
//            printf("dir:%u  ",motor_dir);
//            printf("D:%u  ",DutyCycle);
//            printf("dir2:%u  ",motor_dir2);
//            printf("D2:%u  \r\n",DutyCycle2);
        }




    }
}










