#include "./BSP/AS5600/as5600.h"
#include "./BSP/IIC/myiic.h"
#include "./SYSTEM/usart/usart.h"

uint16_t main_raw_num=0;
uint16_t main_val_num=0;
int magnetStatus = 0; //�ſ�3��״̬ (MD, ML, MH)

int lowbyte; //raw angle 7:0
//word highbyte; //raw angle 7:0 and 11:8
int rawAngle; //final raw angle 
float degAngle; //raw angle in degrees (360/4096 * [value between 0-4095])

int quadrantNumber, previousquadrantNumber; //quadrant IDs
float numberofTurns = 0; //number of turns
float correctedAngle = 0; //tared angle - based on the startup value
float startAngle = 0; //starting angle
float totalAngle = 0; //total absolute angular displacement
float previoustotalAngle = 0; //for the display printing

    
float get_as5600_val(void){
    main_raw_num = AS5600_ReadTwoByte(IIC_raw_ang_hi,IIC_raw_ang_lo);  //��ȡ�����Ĵ�����ֵ
    correctedAngle = (main_raw_num*360)/4096; //�ԼĴ���ֵ���д����õ��Ƕ�ֵ
    
//    printf("    main_raw_num:%u",main_raw_num);
//    printf("    correctedAngle:%f",correctedAngle);
    
    //Quadrant 1
    if(correctedAngle >= 0 && correctedAngle <=90)
    {
    quadrantNumber = 1;
    }

    //Quadrant 2
    if(correctedAngle > 90 && correctedAngle <=180)
    {
    quadrantNumber = 2;
    }

    //Quadrant 3
    if(correctedAngle > 180 && correctedAngle <=270)
    {
    quadrantNumber = 3;
    }

    //Quadrant 4
    if(correctedAngle > 270 && correctedAngle <360)
    {
    quadrantNumber = 4;
    }
    //Serial.print("Quadrant: ");
    //Serial.println(quadrantNumber); //print our position "quadrant-wise"

    if(quadrantNumber != previousquadrantNumber) //if we changed quadrant
    {
    if(quadrantNumber == 1 && previousquadrantNumber == 4)
    {
      numberofTurns++; // 4 --> 1 transition: CW rotation
      previousquadrantNumber=1;
    }

    if(quadrantNumber == 4 && previousquadrantNumber == 1)
    {
      numberofTurns--; // 1 --> 4 transition: CCW rotation
      previousquadrantNumber=4;
    }
    //this could be done between every quadrants so one can count every 1/4th of transition

    previousquadrantNumber = quadrantNumber;  //update to the current quadrant

    }  
    //Serial.print("Turns: ");
    //Serial.println(numberofTurns,0); //number of turns in absolute terms (can be negative which indicates CCW turns)  

    //after we have the corrected angle and the turns, we can calculate the total absolute position
    totalAngle = (numberofTurns*360) + correctedAngle; //number of turns (+/-) plus the actual angle within the 0-360 range

    return totalAngle;
    //printf("    totalAngle:%f\r\n",totalAngle);
    //Serial.print("Total angle: ");
    //Serial.println(totalAngle, 2); //absolute position of the motor expressed in degree angles, 2 digits
}

