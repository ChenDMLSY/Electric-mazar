#ifndef _AS5600_H
#define _AS5600_H
#include "./SYSTEM/sys/sys.h"

float get_as5600_val(void);

#endif

